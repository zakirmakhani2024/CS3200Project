import LivestreamList from "./livestream/livestream-list";
import LivestreamFormEditor from "./livestream/livestream-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM; 
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/livestream", "/"]} exact={true}>
                    <LivestreamList/>
                </Route>
                <Route path="/livestream/:id" exact={true}>
                    <LivestreamFormEditor/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;
