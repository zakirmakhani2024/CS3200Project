// TODO: declare URL where server listens for HTTP requests
const CHAT_URL = "http://localhost:8080/api/chat"

// TODO: retrieve all CHAT from the server
export const findAllChats = () => {
  return fetch(CHAT_URL).then(response => response.json())
}

// TODO: retrieve a single chat by their ID
export const findChatById = (id) => {
  return fetch(`${CHAT_URL}/${id}`).then(response => response.json())
}

// TODO: delete a chat by their ID
export const deleteChat = (id) => {
  return fetch(`${CHAT_URL}/${id}`, {
    method: "DELETE"
  })
}

// TODO: create a new chat
export const createChat = (chat) => {
  return fetch(CHAT_URL, {
    method: 'POST',
    body: JSON.stringify(chat),
    headers: {'content-type': 'application/json'}
  }).then(response => response.json())
}

// TODO: update a chat by their ID
export const updateChat = (id, chat) => {
  return fetch(`${CHAT_URL}/${id}`, {
    method: 'PUT',
    body: JSON.stringify(chat),
    headers: {'content-type': 'application/json'}
  }).then(response => response.json())
}

export const getLivestream = (id) => {
  return fetch(`${CHAT_URL}/${id}/livestream`)
  .then(response => response.json());
}

export const getUser = (id) => {
  return fetch(`${CHAT_URL}/${id}/user`)
  .then(response => response.json());
}

export const getEmote = (id) => {
  return fetch(`${CHAT_URL}/emote`)
  .then(response => response.json());
}

// TODO: export all functions as the API to this service
export default {
  findAllChats,
  findChatById,
  deleteChat,
  createChat,
  updateChat,
  getLivestream,
  getUser,
  getEmote
}
