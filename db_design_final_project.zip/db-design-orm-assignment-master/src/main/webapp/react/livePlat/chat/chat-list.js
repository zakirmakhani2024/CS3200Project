const {Link, useHistory} = window.ReactRouterDOM;
import chatService from "./chat-service"
const {useState, useEffect} = React;
const ChatList = () => {
  const history = useHistory()
  const [chats, setChats] = useState([])
  useEffect(() => {
    findAllChats()
  }, [])
  const findAllChats = () =>
      chatService.findAllChats()
      .then(chats => setChats(chats))
  return (
      <div>
        <h2>Chat List</h2>
        <button onClick={() => history.push("/chat/new")}>
          Add Chat
        </button>
        <ul className="list-group">
          {
            chats.map(chat =>
                <li key={chat.id} className="list-group-item">
                  <Link to={`/chat/${chat.id}`}>
                    {chat.content},
                    {chat.emote}
                  </Link>
                </li>)
          }
        </ul>
      </div>
  )
}

export default ChatList;