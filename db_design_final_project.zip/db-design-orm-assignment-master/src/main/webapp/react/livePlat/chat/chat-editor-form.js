import chatService from "./chat-service"
const {useState, useEffect} = React;
const {useParams, useHistory} = window.ReactRouterDOM;
const {Link, useHistory2} = window.ReactRouterDOM;

const ChatFormEditor = () => {
  const {id} = useParams()
  const [chat, setChat] = useState({})
  const [user, setUser] = useState({})
  const [livestream, setLivestream] = useState({})
  useEffect(() => {
    if (id !== "new") {
      findChatById(id)
      getUser(id)
      getLivestream(id)
    }
  }, []);
  const createChat = (chat) =>
      chatService.createChat(chat)
      .then(() => history.back())
  const findChatById = (id) =>
      chatService.findChatById(id).then(chat => setChat(chat))
  const deleteChat = (id) =>
      chatService.deleteChat(id).then(() => history.back())
  const updateChat = (id, newChat) =>
      chatService.updateChat(id, newChat).then(() => history.back())
  const getUser = (id) =>
      chatService.getUser(id)
  .then(user => setUser(user))
  const getLivestream = (id) =>
      chatService.getLivestream(id)
  .then(livestream => setLivestream(livestream))
  return (
      <div>
        <h2>Chat Editor</h2>
        <label>ID</label>
        <input value={chat.id}/><br/>
        <label>Content</label>
        <input onChange={(e) =>
            setChat(chat =>
                ({...chat, content: e.target.value}))}
               value={chat.content}/><br/>
        <label>Emote</label>
        <input onChange={(e) =>
            setChat(chat =>
                ({...chat, emote: e.target.value}))}
               value={chat.emote}/><br/>
        <label>User</label>
        <input
               value={user.username}/><br/>
        <li className="list-group-item">
          <Link to={`/chat/${chat.id}/user`}>
            {user.username}
          </Link>
        </li>
        <label>Livestream</label>
        <input
               value={livestream.title}/><br/>
        <li className="list-group-item">
          <Link to={`/chat/${chat.id}/livestream`}>
            {livestream.title}
          </Link>
        </li>
        <button
            onClick={() => {
              history.back()
            }}>
          Cancel
        </button>
        <button
            onClick={() => deleteChat(chat.id)}>
          Delete
        </button>
        <button
            onClick={() => createChat(chat)}>
          Create
        </button>
        <button
            onClick={() => updateChat(chat.id, chat)}>
          Save
        </button>
        <button
            onClick={() => updateChat(chat.id, goLive(chat.id))}>
          Live
        </button>
      </div>
  )
}

export default ChatFormEditor