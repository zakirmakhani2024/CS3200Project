import ClipList from "./clips/clips-list";
import ClipFormEditor from "./clips/clips-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM;
const App = () => {
  return (
      <div className="container-fluid">
        <HashRouter>
          <Route path={["/clip", "/"]} exact={true}>
            <ClipList/>
          </Route>
          <Route path="/clip/:id" exact={true}>
            <ClipFormEditor/>
          </Route>
        </HashRouter>
      </div>
  );
}

export default App;
