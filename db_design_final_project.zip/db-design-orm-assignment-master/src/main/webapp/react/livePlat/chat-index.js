import ChatList from "./chat/chat-list";
import ChatFormEditor from "./chat/chat-editor-form";
const {HashRouter, Route} = window.ReactRouterDOM;
const App = () => {
  return (
      <div className="container-fluid">
        <HashRouter>
          <Route path={["/chat", "/"]} exact={true}>
            <ChatList/>
          </Route>
          <Route path="/chat/:id" exact={true}>
            <ChatFormEditor/>
          </Route>
        </HashRouter>
      </div>
  );
}

export default App;
