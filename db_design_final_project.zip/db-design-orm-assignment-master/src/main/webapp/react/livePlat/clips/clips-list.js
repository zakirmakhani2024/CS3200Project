const {Link, useHistory} = window.ReactRouterDOM;
import clipService from "./clips-service"
const {useState, useEffect} = React;
const ClipList = () => {
  const history = useHistory()
  const [clips, setClips] = useState([])
  useEffect(() => {
    findAllClips()
  }, [])
  const findAllClips = () =>
      clipService.findAllClips()
      .then(clips => setClips(clips))
  return (
      <div>
        <h2>Clip List</h2>
        <button onClick={() => history.push("/clips/new")}>
          Add Clip
        </button>
        <ul className="list-group">
          {
            clips.map(clip =>
                <li key={clip.id} className="list-group-item">
                  <Link to={`/clips/${clip.id}`}>
                    {clip.title}
                  </Link>
                </li>)
          }
        </ul>
      </div>
  )
}

export default ClipList;