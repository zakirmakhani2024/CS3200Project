// TODO: declare URL where server listens for HTTP requests
const CLIPS_URL = "http://localhost:8080/api/clips"

// TODO: retrieve all users from the server
export const findAllClips = () => {
  return fetch(CLIPS_URL).then(response => response.json())
}

// TODO: retrieve a single user by their ID
export const findClipById = (id) => {
  return fetch(`${CLIPS_URL}/${id}`).then(response => response.json())
}

// TODO: delete a user by their ID
export const deleteClip = (id) => {
  return fetch(`${CLIPS_URL}/${id}`, {
    method: "DELETE"
  })
}

// TODO: create a new user
export const createClip = (clip) => {
  return fetch(CLIPS_URL, {
    method: 'POST',
    body: JSON.stringify(clip),
    headers: {'content-type': 'application/json'}
  }).then(response => response.json())
}

// TODO: update a user by their ID
export const updateClip = (id, clip) => {
  return fetch(`${CLIPS_URL}/${id}`, {
    method: 'PUT',
    body: JSON.stringify(clip),
    headers: {'content-type': 'application/json'}
  }).then(response => response.json())
}

export const getLivestream = (id) => {
  return fetch(`${CLIPS_URL}/${id}/livestream`)
  .then(response => response.json())
}

// TODO: export all functions as the API to this service
export default {
  findAllClips,
  findClipById,
  deleteClip,
  createClip,
  updateClip,
  getLivestream
}
