import clipService from "./clips-service"
const {useState, useEffect} = React;
const {useParams, useHistory} = window.ReactRouterDOM;
const ClipFormEditor = () => {
  const {id} = useParams()
  const [clip, setClip] = useState({})
  const [livestream, setLivestream] = UseState({})
  useEffect(() => {
    if (id !== "new") {
      findClipById(id)
      getLivestream(id)
    }
  }, []);
  const createClip = (clip) =>
      clipService.createClip(clip)
      .then(() => history.back())
  const findClipById = (id) =>
      clipService.findClipById(id).then(clip => setClip(clip))
  const deleteClip = (id) =>
      clipService.deleteClip(id).then(() => history.back())
  const updateClip = (id, newClip) =>
      clipService.updateClip(id, newClip).then(() => history.back())
  const getLivestream = (id) =>
      clipService.getLivestream(id)
      .then(livestream => setLivestream(livestream))
  return (
      <div>
        <h2>Clip Editor</h2>
        <label>ID</label>
        <input value={clip.id}/><br/>
        <label>Seconds</label>
        <input onChange={(e) =>
            setClip(clip =>
                ({...clip, seconds: e.target.value}))}
               value={clip.seconds}/><br/>
        <label>Views</label>
        <input onChange={(e) =>
            setClip(clip =>
                ({...clip, views: e.target.value}))}
               value={clip.views}/><br/>
        <label>Livestream</label>
        <input
               value={livestream.title}/><br/>
        <li className="list-group-item">
          <Link to={`/clips/${clipId}/livestream`}>
            {livestream.title},
          </Link>
        </li>
        <label>Title</label>
        <input onChange={(e) =>
            setClip(clip =>
                ({...clip, title: e.target.value}))}
               value={clip.title}/><br/>
        <button
            onClick={() => {
              history.back()
            }}>
          Cancel
        </button>
        <button
            onClick={() => deleteClip(clip.id)}>
          Delete
        </button>
        <button
            onClick={() => createClip(clip)}>
          Create
        </button>
        <button
            onClick={() => updateClip(clip.id, clip)}>
          Save
        </button>
      </div>
  )
}

export default ClipFormEditor