import livestreamService from "./livestream-service"
const {Link, useHistory} = window.ReactRouterDOM;
const LIVESTREAM_URL = "http://localhost:8080/api/livestreams"
const { useState, useEffect } = React;

const LivestreamList = () => {
  const history = useHistory()
  const [livestreams, setLivestreams] = useState([])
  useEffect(() => {
    findAllLivestreams()
  }, [])
  const findAllLivestreams = () =>
      livestreamService.findAllLivestreams()
      .then(users => setLivestreams(users))
  return (
      <div>
        <h2>Livestream List</h2>
        <ul className="list-group">
          {
            livestreams.map(livestream =>
                <li key={livestream.id} className="list-group-item">
                  <Link to={`/livestream/${livestream.id}`}>
                    {livestream.title}
                  </Link>
                </li>)
          }
        </ul>
      </div>
  )
}

export default LivestreamList;