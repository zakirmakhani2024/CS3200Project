import livestreamService from "./livestream-service"

const {useState, useEffect} = React
const {useParams, useHistory} = window.ReactRouterDOM;
const {Link, useHistory2} = window.ReactRouterDOM;
const LIVESTREAM_URL = "http://localhost:8080/api/livestream"

const livestreamFormEditor = () => {
  const [livestream, setLivestream] = useState({})
  const [users, setUsers] = useState({})
  const [clips, setSetClips] = useState({})
  const [chats, setChats] = useState({})
  const {id} = useParams()
  useEffect(() => {
    if (id !== "new") {
      findLivestreamById(id)
      getUsers(id)
      getClips(id)
      getChats(id)
    }

  }, []);
  const findLivestreamById = (id) =>
      livestreamService.findLivestreamById(id)
      .then(livestream => setLivestream(livestream))
  const updateLivestream = (id, newLivestream) =>
      livestreamService.updateLivestream(id, newLivestream)
      .then(() => history.back())
  const deleteLivestream = (id) =>
      livestreamService.deleteLivestream(id)
      .then(() => history.back())
  const getUsers = (id) =>
      livestreamService.getUsers(id)
  .then(users => setUsers(users))
  const getClips = (id) =>
      livestreamService.getClips(id)
      .then(clips => setClips(clips))
  const getChats = (id) =>
      livestreamService.getChats(id)
      .then(chats => setChats(chats))
  const kickUser = (lid, uid) =>
      livestreamService.kickUser(lid, uid)

  return (
      <div>
        <h2>Livestream Editor</h2>
        <label>ID</label>
        <input value={livestream.id}/><br/>
        <label>Seconds Live</label>
        <input onChange={(e) =>
            setLivestream(livestream =>
                ({...livestream, seconds: e.target.value}))}
               value={livestream.seconds}/><br/>
        <label>Viewers</label>
        <input onChange={(e) =>
            setLivestream(livestream =>
                ({...livestream, viewers: e.target.value}))}
               value={livestream.viewers}/><br/>
        <label>Title</label>
        <input onChange={(e) =>
            setLivestream(livestream =>
                ({...livestream, title: e.target.value}))}
               value={livestream.title}/><br/>
        <li className="list-group-item">
          <Link to={`/livestream/${livestream.id}/users`}>
            {"Users"}
          </Link>
        </li>
        <li className="list-group-item">
          <Link to={`/livestream/${livestream.id}/clips`}>
            {"Clips"}
          </Link>
        </li>
        <li className="list-group-item">
          <Link to={`/livestream/${livestream.id}/chats`}>
            {"Chats"}
          </Link>
        </li>
        <button
            onClick={() => {
              history.back()
            }}>
          Cancel
        </button>
        <button
            onClick={() => deleteLivestream(livestream.id)}>
          Delete
        </button>
        <button
            onClick={() => updateLivestream(livestream.id, livestream)}>
          Save
        </button>
      </div>
  )
}

export default livestreamFormEditor