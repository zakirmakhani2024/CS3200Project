const LIVESTREAM_URL = "http://localhost:8080/api/livestream"

export const createLivestream = (livestream) =>
    fetch(LIVESTREAM_URL, {
      method: 'POST',
      body: JSON.stringify(livestream),
      headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

export const findAllLivestreams = () =>
    fetch(LIVESTREAM_URL)
    .then(response => response.json())

export const findLivestreamById = (id) =>
    fetch(`${LIVESTREAM_URL}/${id}`)
    .then(response => response.json())

export const updateLivestream = (id, livestream) =>
    fetch(`${LIVESTREAM_URL}/${id}`, {
      method: 'PUT',
      body: JSON.stringify(livestream),
      headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

const deleteLivestream = (id) =>
    fetch(`${LIVESTREAM_URL}/${id}`, {
      method: "DELETE"
    })

const getUsers = (id) =>
    fetch(`${LIVESTREAM_URL}/${id}/users`)
    .then(response => response.json())

const kickUser = (lid, uid) =>
    fetch(`${LIVESTREAM_URL}/${lid}/kick/${uid}`)
    .then(response => response.json())

const getClips = (lid) =>
    fetch(`${LIVESTREAM_URL}/${lid}/clips`)
    .then(response => response.json())

const getChats = (lid) =>
    fetch(`${LIVESTREAM_URL}/${lid}/chats`)
    .then(response => response.json())
export default {
  createLivestream,
  findAllLivestreams,
  findLivestreamById,
  updateLivestream,
  deleteLivestream,
  getUsers,
  getClips,
  getChats,
  kickUser
}