package com.example.springtemplate.daos;

import com.example.springtemplate.models.Clips;
import com.example.springtemplate.models.Livestream;
import com.example.springtemplate.repositories.ClipRepository;
import com.example.springtemplate.repositories.LivestreamRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class ClipOrmDao {
  @Autowired
  ClipRepository clipRepository;

  @Autowired
  LivestreamRepository livestreamRepository;

  @PostMapping("/api/clips")
  public Clips createClip(@RequestBody Clips clip) {
    return clipRepository.save(clip);
  }

  @GetMapping("/api/clips")
  public List<Clips> findAllClips() {
    return (List<Clips>) clipRepository.findAll();
  }

  @GetMapping("/api/clips/{clipId}")
  public Clips findClipById(
      @PathVariable("clipId") Integer id) {
    return clipRepository.findById(id).get();
  }

  @PutMapping("/api/clips/{clipId}")
  public Clips updateClip(
      @PathVariable("clipId") Integer id,
      @RequestBody() Clips newClip) {
    Clips clip = clipRepository.findById(id).get();
    clip.setTitle(newClip.getTitle());
    clip.setSeconds(newClip.getSeconds());
    clip.setLivestream(newClip.getLivestream());
    clip.setViewers(newClip.getViews());
    return clipRepository.save(clip);
  }

  @GetMapping("/api/clips/{clipId}/livestream")
  public Livestream getLivestream(
      @PathVariable("clipId") Integer cid) {
    Clips clip = clipRepository.findById(cid).get();
    return clip.getLivestream();
  }
}
