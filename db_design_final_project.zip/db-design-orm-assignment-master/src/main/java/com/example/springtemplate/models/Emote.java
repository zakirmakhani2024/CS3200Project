package com.example.springtemplate.models;

public enum Emote {
  PEPELAUGH("PepeLaugh"), LULW("LULW"), OMEGALUL("OMEGALUL");

  public final String label;

  private Emote(String label) {
    this.label = label;
  }
}
