package com.example.springtemplate.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "livestream")
public class Livestream {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  private Integer seconds;
  private Integer viewers;
  private String title;

  @OneToMany(mappedBy = "livestream")
  @JsonIgnore
  private List<User> users;

  @OneToMany(mappedBy = "livestream")
  @JsonIgnore
  private List<Clips> clips;

  @OneToMany(mappedBy = "livestream")
  @JsonIgnore
  private List<Chat> chats;

  public List<User> getUsers() {
    return this.users;
  }

  public void setUsers(List<User> users) {
    this.users = users;
  }

  public List<Clips> getClips() {
    return this.clips;
  }

  public void setClips(List<Clips> clips) {
    this.clips = clips;
  }

  public Integer getId() {
    return this.id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getSeconds() {
    return this.seconds;
  }

  public void setSeconds(Integer seconds) {
    this.seconds = seconds;
  }

  public Integer getViewers() {
    return this.viewers;
  }

  public void setViewers(Integer viewers) {
    this.viewers = viewers;
  }

  public String getTitle() {
    return this.title;
  }

  public List<Chat> getChats() {
    return this.chats;
  }

  public void setChats(List<Chat> chats) {
    this.chats = chats;
  }


  public void setTitle(String title) {
    this.title = title;
  }

  @Override
  public String toString() {
    return this.title;
  }

  public Livestream() {
    this.seconds = 0;
    this.viewers = 0;
    this.title = "Welcome";
  }
}
