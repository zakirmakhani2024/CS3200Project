package com.example.springtemplate.daos;

import com.example.springtemplate.models.Chat;
import com.example.springtemplate.models.Emote;
import com.example.springtemplate.models.Livestream;
import com.example.springtemplate.models.User;
import com.example.springtemplate.repositories.ChatRepository;
import com.example.springtemplate.repositories.LivestreamRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class ChatOrmDao {
  @Autowired
  ChatRepository chatRepository;

  @Autowired
  LivestreamRepository livestreamRepository;

  @PostMapping("/api/chat")
  public Chat createChat(@RequestBody Chat chat) {return chatRepository.save(chat);}

  @GetMapping("/api/chat")
  public List<Chat> findAllChats() {return (List<Chat>) chatRepository.findAll();}

  @GetMapping("/api/chat/{chatId}")
  public Chat findChatById(
      @PathVariable("chatId") Integer cid) {
    return chatRepository.findById(cid).get();
  }

  @PutMapping("/api/chat/{chatId}")
  public Chat updateChat(
      @PathVariable("chatId") Integer id,
      @RequestBody() Chat newChat) {
    Chat chat = chatRepository.findById(id).get();
    chat.setContent(newChat.getContent());
    chat.setEmote(newChat.getEmote());
    return chatRepository.save(chat);
  }

  @GetMapping("/api/chat/{chatId}/livestream")
  public Livestream getLivestream(
      @PathVariable("chatId") Integer cid) {
    Chat chat = chatRepository.findById(cid).get();
    return chat.getLivestream();
  }

  @GetMapping("/api/chat/{chatId}/user")
  public User getUser(
      @PathVariable("chatId") Integer cid) {
    Chat chat = chatRepository.findById(cid).get();
    return chat.getUser();
  }

  @DeleteMapping("/api/chat/{chatId}")
  public void deleteLivestream(
      @PathVariable("chatId") Integer id) {
    chatRepository.deleteById(id);
  }

  @GetMapping("/api/chat/{chatId}/emote")
  public Emote getEmote(
      @PathVariable("chatId") Integer cid) {
    Chat chat = chatRepository.findById(cid).get();
    return chat.getEmote();
  }
}
