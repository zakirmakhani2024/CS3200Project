package com.example.springtemplate.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "clips")
public class Clips {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  private Integer seconds;
  private Integer views;
  private String title;
  @ManyToOne
  @JsonIgnore
  private Livestream livestream;

  public Integer getId() {
    return this.id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getSeconds() { return this.seconds; }

  public void setSeconds(Integer seconds) {
    this.seconds = seconds;
  }

  public Integer getViews() {
    return this.views;
  }

  public void setViewers(Integer views) {
    this.views = views;
  }

  public Livestream getLivestream() {
    return this.livestream;
  }

  public void setLivestream(Livestream livestream) {
    this.livestream = livestream;
  }

  public String getTitle() {
    return this.title;
  }

  public void setTitle(String title) {
    this.title = title;
  }
}
