package com.example.springtemplate.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "chat")
public class Chat {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  private String content;

  @Enumerated(value = EnumType.STRING)
  private Emote emote;

  @ManyToOne
  private Livestream livestream;
  @ManyToOne
  private User user;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public User getUser() {
    return user;
  }

  public void setUser(User user) {
    this.user = user;
  }

  public Livestream getLivestream() {
    return livestream;
  }

  public void setLivestream(Livestream livestream) {
    this.livestream = livestream;
  }

  public Emote getEmote() {return this.emote;}

  public void setEmote(Emote emote) {this.emote = emote;}
}
