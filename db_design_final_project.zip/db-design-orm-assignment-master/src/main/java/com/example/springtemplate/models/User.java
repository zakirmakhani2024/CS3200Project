package com.example.springtemplate.models;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name = "users")
public class User {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  private String firstName;
  private String lastName;
  private String username;
  private String password;
  private String email;
  private Date dateOfBirth;
  private Boolean live;

  @ManyToOne
  private Livestream livestream;

  @OneToOne
  private Livestream channel;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public Date getDateOfBirth() {
    return this.dateOfBirth;
  }

  public void setDateOfBirth(Date date) {
    this.dateOfBirth = date;
  }

  public Livestream getLivestream() {
    return livestream;
  }

  public void setLivestream(Livestream livestream) {
    this.livestream = livestream;
  }

  public Livestream getChannel() {
    return this.channel;
  }

  public void setChannel(Livestream channel) {
    this.channel = channel;
  }

  public Boolean getLive() {
    return this.live;
  }

  public void setLive(Boolean live) {
    this.live = live;
  }

  public User(String first_name, String last_name, String username, String password, String email,
     Date dateOfBirth) {
    this.username = username;
    this.password = password;
    this.firstName = first_name;
    this.lastName = last_name;
    this.email = email;
    this.dateOfBirth = dateOfBirth;
    this.livestream = null;
    this.channel = new Livestream();
    this.live = false;
  }

  public User(String first_name, String last_name, String username, String password, String email,
      Date dateOfBirth, Livestream livestream, Livestream channel, Boolean live) {
    this.username = username;
    this.password = password;
    this.firstName = first_name;
    this.lastName = last_name;
    this.email = email;
    this.dateOfBirth = dateOfBirth;
    this.livestream = livestream;
    if (channel == null) {
      this.channel = new Livestream();
      List<User> users  = new ArrayList<User>();
      users.add(this);
      this.channel.setUsers(users);
    }
    else {
      this.channel = channel;
    }
    if (live == null) {
      this.live = false;
    }
    else {
      this.live = live;
    }
  }
  public User() {
    this.channel = new Livestream();
    List<User> users  = new ArrayList<User>();
    users.add(this);
    this.channel.setUsers(users);
    this.live = false;
  }
}
