package com.example.springtemplate.daos;

import com.example.springtemplate.models.Chat;
import com.example.springtemplate.models.Clips;
import com.example.springtemplate.models.Livestream;
import com.example.springtemplate.models.User;
import com.example.springtemplate.repositories.LivestreamRepository;
import com.example.springtemplate.repositories.UserRestRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class LivestreamOrmDao {

  @Autowired
  LivestreamRepository livestreamRepository;

  @Autowired
  UserRestRepository userRepository;

  @PostMapping("/api/livestream")
  public Livestream createLivestream(@RequestBody Livestream livestream) {
    return livestreamRepository.save(livestream);
  }

  @GetMapping("/api/livestream")
  public List<Livestream> findAllLivestreams() {
    return (List<Livestream>) livestreamRepository.findAll();
  }

  @GetMapping("/api/livestream/{livestreamId}")
  public Livestream findLivestreamById(
      @PathVariable("livestreamId") Integer id) {
    return livestreamRepository.findById(id).get();
  }

  @GetMapping("/api/update/livestream/{seconds}/{livestreamId}/{viewers}/{title}")
  public Livestream updateLivestream(
      @PathVariable("livestreamId") Integer id,
      @PathVariable("seconds") Integer seconds,
      @PathVariable("viewers") Integer viewers,
      @PathVariable("title") String title) {
    Livestream livestream = this.findLivestreamById(id);
    livestream.setSeconds(seconds);
    livestream.setViewers(viewers);
    livestream.setTitle(title);
    return livestreamRepository.save(livestream);
  }

  @PutMapping("/api/livestream/{livestreamId}")
  public Livestream updateLivestream(
      @PathVariable("livestreamId") Integer id,
      @RequestBody() Livestream newLivestream) {
    Livestream livestream = this.findLivestreamById(id);
    livestream.setViewers(newLivestream.getViewers());
    livestream.setSeconds(newLivestream.getSeconds());
    livestream.setClips(newLivestream.getClips());
    livestream.setUsers(newLivestream.getUsers());
    livestream.setTitle(newLivestream.getTitle());
    return livestreamRepository.save(livestream);
  }

  @DeleteMapping("/api/livestream/{livestreamId}")
  public void deleteLivestream(
      @PathVariable("livestreamId") Integer id) {
    livestreamRepository.deleteById(id);
  }

  @GetMapping("/api/livestream/{lid}/clips")
  public List<Clips> findClipsForLivestream(
      @PathVariable("lid") Integer livestreamId) {
    Livestream livestream = livestreamRepository.findById(livestreamId).get();
    return livestream.getClips();
  }

  @GetMapping("/api/livestream/{lid}/users")
  public List<User> findUsersForLivestream(
      @PathVariable("lid") Integer livestreamId) {
    Livestream livestream = livestreamRepository.findById(livestreamId).get();
    return livestream.getUsers();
  }

  @GetMapping("/api/livestream/{lid}/chats")
  public List<Chat> findChatsForLivestream(
      @PathVariable("lid") Integer livestreamId) {
    Livestream livestream = livestreamRepository.findById(livestreamId).get();
    return livestream.getChats();
  }

  @GetMapping("/api/livestream/{lid}/title")
  public String getLivestreamTitle(
      @PathVariable("lid") Integer livestreamId) {
    Livestream livestream = livestreamRepository.findById(livestreamId).get();
    return livestream.getTitle();
  }

  @GetMapping("/api/livestream/{lid}/kick/{uid}")
  public Livestream kickUser(
      @PathVariable("lid") Integer livestreamId,
      @PathVariable("uid") Integer userId) {
    Livestream livestream = livestreamRepository.findById(livestreamId).get();
    User user = userRepository.findUserById(userId);
    if (livestream.getUsers().contains(user)) {
      List<User> currentUsers = livestream.getUsers();
      currentUsers.remove(user);
      livestream.setUsers(currentUsers);
    }
    return this.updateLivestream(livestreamId, livestream);
  }
}
