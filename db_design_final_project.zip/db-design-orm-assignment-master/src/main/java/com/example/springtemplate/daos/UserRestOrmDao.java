package com.example.springtemplate.daos;

import com.example.springtemplate.models.Livestream;
import com.example.springtemplate.models.User;
import com.example.springtemplate.repositories.LivestreamRepository;
import com.example.springtemplate.repositories.UserRestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class UserRestOrmDao {
    @Autowired
    UserRestRepository userRepository;

    @Autowired
    LivestreamRepository livestreamRepository;

    @PostMapping("/api/users")
    public User createUser(@RequestBody User user) {
        return userRepository.save(user);
    }

    @GetMapping("/api/users")
    public List<User> findAllUsers() {
        return userRepository.findAllUsers();
    }

    @GetMapping("/api/users/{userId}")
    public User findUserById(
            @PathVariable("userId") Integer id) {
        return userRepository.findUserById(id);
    }

    @PutMapping("/api/users/{userId}")
    public User updateUser(
            @PathVariable("userId") Integer id,
            @RequestBody User userUpdates) {
        User user = userRepository.findUserById(id);
        user.setFirstName(userUpdates.getFirstName());
        user.setLastName(userUpdates.getLastName());
        user.setUsername(userUpdates.getUsername());
        user.setPassword(userUpdates.getPassword());
        user.setEmail(userUpdates.getEmail());
        user.setLivestream(userUpdates.getLivestream());
        user.setChannel(userUpdates.getChannel());
        user.setLive(userUpdates.getLive());
        return userRepository.save(user);
    }

    @GetMapping("/api/users/channel/{userId}")
    public Livestream getUserChannel(
        @PathVariable("userId") Integer id) {
        User user = userRepository.findById(id).get();
        Livestream channel = user.getChannel();
        return channel;
    }

    @GetMapping("/api/users/livestream/{uid}/")
    public Livestream findLivestreamForUser(
        @PathVariable("uid") Integer userId) {
        User user = userRepository.findById(userId).get();
        Livestream livestream = user.getLivestream();
        return livestream;
    }

    @DeleteMapping("/api/users/{userId}")
    public void deleteUser(
            @PathVariable("userId") Integer id) {
        userRepository.deleteById(id);
    }

    @GetMapping("/api/users/{userId}/live")
    public User goLive(
        @PathVariable("userId") Integer id) {
        User user = userRepository.findUserById(id);
        user.setLive(!user.getLive());
        return this.updateUser(id, user);
    }

    @GetMapping("/api/users/livestream/{uid}/{lid}")
    public User joinLivestream(
        @PathVariable("uid") Integer uid,
        @PathVariable("lid") Integer lid) {
        User user = userRepository.findUserById(uid);
        Livestream livestream = livestreamRepository.findById(lid).get();
        Livestream oldLivestream = user.getLivestream();
        if (oldLivestream != null) {
            List<User> oldUsers = oldLivestream.getUsers();
            oldUsers.remove(user);
            oldLivestream.setUsers(oldUsers);
            oldLivestream.setViewers(oldLivestream.getViewers() - 1);
        }
        livestream.setViewers(livestream.getViewers() + 1);
        List<User> newUsers = livestream.getUsers();
        newUsers.add(user);
        livestream.setUsers(newUsers);
        user.setLivestream(livestream);
        return userRepository.save(user);
    }
}